package com.livingworld.app;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Build;
import android.os.PowerManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.Display;
import android.view.WindowManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status;
    private TextView diagnostics;
    private String diagnosticReport = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("living_world", MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 40, 28, 28);
        root.setBackgroundColor(Color.rgb(8, 14, 28));
        root.setGravity(Gravity.TOP);
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("LIVING WORLD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Adaptive live wallpaper • Redmi Pad Pro");
        subtitle.setTextColor(Color.rgb(155, 183, 220));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, 8, 0, 26);
        root.addView(subtitle);

        Switch max = new Switch(this);
        max.setText("MAX PERFORMANCE");
        max.setTextColor(Color.WHITE);
        max.setTextSize(19);
        max.setPadding(0, 12, 0, 20);
        max.setChecked(prefs.getBoolean("max", false));
        root.addView(max);
        max.setOnCheckedChangeListener((button, checked) -> {
            prefs.edit().putBoolean("max", checked).apply();
            status.setText(checked
                ? "MAX mode enabled for Living World. The system still controls CPU/GPU clocks and temperature."
                : "Balanced mode enabled.");
        });

        status = new TextView(this);
        status.setTextColor(Color.rgb(195, 211, 235));
        status.setTextSize(15);
        status.setPadding(0, 14, 0, 24);
        status.setText(max.isChecked()
            ? "MAX mode enabled for Living World. The system still controls CPU/GPU clocks and temperature."
            : "Balanced mode enabled.");
        root.addView(status);

        Button preview = new Button(this);
        preview.setText("OPEN LIVE WALLPAPER SETTINGS");
        root.addView(preview);
        preview.setOnClickListener(v -> {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, LivingWorldWallpaperService.class));
            try { startActivity(intent); }
            catch (Exception e) {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            }
        });

        Button inspect = new Button(this);
        inspect.setText("CHECK DEVICE / PERFORMANCE INFO");
        root.addView(inspect);
        diagnostics = new TextView(this);
        diagnostics.setTextColor(Color.rgb(195, 211, 235));
        diagnostics.setTextSize(13);
        diagnostics.setPadding(0, 12, 0, 8);
        diagnostics.setText("Device report not generated yet.");
        root.addView(diagnostics);
        inspect.setOnClickListener(v -> {
            diagnosticReport = createDeviceReport();
            diagnostics.setText(diagnosticReport);
        });

        Button copy = new Button(this);
        copy.setText("COPY DEVICE REPORT");
        root.addView(copy);
        copy.setOnClickListener(v -> {
            if (diagnosticReport.isEmpty()) diagnosticReport = createDeviceReport();
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Living World device report", diagnosticReport));
            status.setText("Device report copied. You can paste it into ChatGPT.");
        });

        TextView note = new TextView(this);
        note.setText("\nMAX mode optimizes only Living World's drawing. Android controls CPU/GPU clocks, thermal limits, and whether wallpaper rendering is paused while a game is foreground. A normal app cannot activate disabled cores or boost other apps.");
        note.setTextColor(Color.rgb(140, 155, 180));
        note.setTextSize(13);
        root.addView(note);
    }
    private String createDeviceReport() {
        StringBuilder out = new StringBuilder();
        out.append("Living World device report\n");
        out.append("Manufacturer: ").append(Build.MANUFACTURER).append("\n");
        out.append("Model: ").append(Build.MODEL).append("\n");
        out.append("Device: ").append(Build.DEVICE).append("\n");
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("Available CPU cores reported to app: ").append(Runtime.getRuntime().availableProcessors()).append("\n");
        Runtime rt = Runtime.getRuntime();
        out.append("App max heap: ").append(rt.maxMemory() / (1024 * 1024)).append(" MB\n");
        android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
        android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        out.append("Device RAM total: ").append(mi.totalMem / (1024 * 1024)).append(" MB\n");
        out.append("Device RAM available now: ").append(mi.availMem / (1024 * 1024)).append(" MB\n");
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        out.append("Current display refresh rate: ").append(display.getRefreshRate()).append(" Hz\n");
        out.append("Power saver: ");
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        out.append(pm.isPowerSaveMode() ? "ON" : "OFF").append("\n");
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                int thermal = pm.getCurrentThermalStatus();
                String[] names = {"NONE", "LIGHT", "MODERATE", "SEVERE", "CRITICAL", "EMERGENCY", "SHUTDOWN"};
                out.append("Thermal status: ").append(thermal >= 0 && thermal < names.length ? names[thermal] : thermal).append("\n");
            } catch (Exception e) { out.append("Thermal status: unavailable to app\n"); }
        } else out.append("Thermal status: API not available on this Android version\n");
        out.append("\nNote: these are diagnostic readings, not proof of maximum CPU/GPU clocks. Android may hide hardware details.");
        return out.toString();
    }

}
