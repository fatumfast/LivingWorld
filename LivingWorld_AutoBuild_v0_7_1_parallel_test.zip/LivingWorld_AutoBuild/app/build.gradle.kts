plugins {
    id("com.android.application")
}

android {
    namespace = "com.livingworld.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.livingworld.app.v071"
        minSdk = 26
        targetSdk = 35
        versionCode = 7
        versionName = "0.7.1"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
