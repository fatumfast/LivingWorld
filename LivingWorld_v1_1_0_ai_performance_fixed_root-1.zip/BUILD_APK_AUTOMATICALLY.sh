#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if ! command -v java >/dev/null 2>&1; then
  echo "Java is required. Install a JDK 17."
  exit 1
fi
if [[ ! -x ./gradlew ]]; then
  echo "Gradle wrapper is missing. Generate it on a computer with Gradle installed:"
  echo "  gradle wrapper --gradle-version 8.9"
  exit 1
fi
./gradlew --no-daemon assembleDebug
echo "APK: app/build/outputs/apk/debug/app-debug.apk"
