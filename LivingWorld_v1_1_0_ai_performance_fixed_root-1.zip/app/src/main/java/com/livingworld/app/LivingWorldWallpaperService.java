package com.livingworld.app;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.view.Choreographer;
import android.view.Display;
import android.hardware.display.DisplayManager;
import android.view.Surface;
import android.os.SystemClock;
import android.os.PowerManager;
import android.os.Build;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Shader;
import android.graphics.LinearGradient;
import android.graphics.RadialGradient;
import android.graphics.Matrix;
import java.util.Random;

/** Lightweight Canvas renderer. Android owns visibility and thermal/power policy. */
public class LivingWorldWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new WorldEngine(); }

    private final class WorldEngine extends Engine {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Matrix orbMatrix = new Matrix();
        private boolean visible;
        private long start = SystemClock.elapsedRealtime();
        private int cachedW = -1, cachedH = -1;
        private LinearGradient backgroundGradient;
        private RadialGradient orbGradient;
        private float orbRadius;
        private float[] starX = new float[0], starY = new float[0], starPhase = new float[0];
        private final Choreographer choreographer = Choreographer.getInstance();
        private long lastFrameNanos = 0L;
        private float requestedSurfaceRate = 0f;
        private int lastTargetFps = -1;
        private long sampleStartNanos = 0L;
        private int sampleFrames = 0;
        private int sampleSlowFrames = 0;
        private long sampleRenderNanos = 0L;
        private final Choreographer.FrameCallback frameCallback = this::onVsync;

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) {
                lastFrameNanos = 0L;
                sampleStartNanos = SystemClock.elapsedRealtimeNanos();
                sampleFrames = 0;
                sampleSlowFrames = 0;
                sampleRenderNanos = 0L;
                choreographer.removeFrameCallback(frameCallback);
                choreographer.postFrameCallback(frameCallback);
            } else {
                choreographer.removeFrameCallback(frameCallback);
            }
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            rebuildCaches(width, height);
            updateSurfaceFrameRate();
            if (visible) {
                choreographer.removeFrameCallback(frameCallback);
                choreographer.postFrameCallback(frameCallback);
            }
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            choreographer.removeFrameCallback(frameCallback);
            super.onSurfaceDestroyed(holder);
        }

        private void rebuildCaches(int w, int h) {
            if (w <= 0 || h <= 0 || (w == cachedW && h == cachedH)) return;
            cachedW = w; cachedH = h;
            backgroundGradient = new LinearGradient(0, 0, 0, h,
                Color.rgb(8, 20, 50), Color.rgb(2, 4, 12), Shader.TileMode.CLAMP);
            orbRadius = Math.min(w, h) * 0.22f;
            float r = Math.max(1f, orbRadius);
            orbGradient = new RadialGradient(-r * .25f, -r * .3f, r * 1.5f,
                new int[]{Color.rgb(95, 205, 255), Color.rgb(27, 75, 155), Color.rgb(4, 13, 43)},
                null, Shader.TileMode.CLAMP);
            int count = 320;
            starX = new float[count]; starY = new float[count]; starPhase = new float[count];
            Random random = new Random(71);
            for (int i = 0; i < count; i++) {
                starX[i] = random.nextFloat() * w;
                starY[i] = random.nextFloat() * h;
                starPhase[i] = random.nextFloat() * 6.2831855f;
            }
        }

        private float getMaximumRefreshRate() {
            try {
                DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
                Display display = dm != null ? dm.getDisplay(Display.DEFAULT_DISPLAY) : null;
                if (display == null) return 60f;
                float max = display.getRefreshRate();
                if (Build.VERSION.SDK_INT >= 23) {
                    for (Display.Mode mode : display.getSupportedModes()) {
                        max = Math.max(max, mode.getRefreshRate());
                    }
                }
                return Math.max(30f, max);
            } catch (RuntimeException ignored) {
                return 60f;
            }
        }

        private int calculateTargetFps() {
            SharedPreferences prefs = getSharedPreferences("living_world", MODE_PRIVATE);
            boolean max = prefs.getBoolean("max", false);
            float displayMax = getMaximumRefreshRate();
            int target = max ? Math.max(60, Math.round(displayMax)) : 30;
            PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
            // User preference: only our app's power-saver policy may lower the target.
            // Do not voluntarily lower the target based on thermal status; Android may still
            // throttle rendering/refresh globally to protect the device from overheating.
            if (pm != null && pm.isPowerSaveMode()) target = Math.min(target, 60);
            return Math.max(15, target);
        }

        private void updateSurfaceFrameRate() {
            int target = calculateTargetFps();
            if (target == lastTargetFps) return;
            lastTargetFps = target;
            try {
                Surface surface = getSurfaceHolder().getSurface();
                if (surface != null && surface.isValid() && Build.VERSION.SDK_INT >= 31) {
                    // A preference request, not a guarantee; Android/display policy remains authoritative.
                    surface.setFrameRate((float) target, Surface.FRAME_RATE_COMPATIBILITY_FIXED_SOURCE,
                        Surface.CHANGE_FRAME_RATE_ALWAYS);
                    requestedSurfaceRate = target;
                } else {
                    requestedSurfaceRate = 0f;
                }
            } catch (RuntimeException ignored) {
                requestedSurfaceRate = 0f;
            }
        }

        private void onVsync(long frameTimeNanos) {
            if (!visible) return;
            choreographer.postFrameCallback(frameCallback);
            int targetFps = calculateTargetFps();
            if (targetFps != lastTargetFps) updateSurfaceFrameRate();
            long interval = 1_000_000_000L / Math.max(1, targetFps);
            if (lastFrameNanos != 0L && frameTimeNanos - lastFrameNanos < interval) return;
            long previousFrame = lastFrameNanos;
            lastFrameNanos = frameTimeNanos;
            if (previousFrame != 0L && frameTimeNanos - previousFrame > 20_000_000L) sampleSlowFrames++;
            long renderStart = SystemClock.elapsedRealtimeNanos();
            drawFrame();
            long renderDuration = SystemClock.elapsedRealtimeNanos() - renderStart;
            sampleRenderNanos += renderDuration;
            sampleFrames++;
            if (sampleStartNanos == 0L) sampleStartNanos = frameTimeNanos;
            long elapsed = SystemClock.elapsedRealtimeNanos() - sampleStartNanos;
            if (elapsed >= 2_000_000_000L) publishPerformanceSample(elapsed);
        }

        private void publishPerformanceSample(long elapsedNanos) {
            float fps = sampleFrames * 1_000_000_000f / Math.max(1L, elapsedNanos);
            float averageMs = sampleFrames == 0 ? 0f : sampleRenderNanos / 1_000_000f / sampleFrames;
            getSharedPreferences("living_world_perf", MODE_PRIVATE).edit()
                .putBoolean("renderer_active", visible && sampleFrames > 0)
                .putFloat("measured_fps", Math.round(fps * 10f) / 10f)
                .putFloat("avg_render_ms", Math.round(averageMs * 100f) / 100f)
                .putInt("slow_frames", sampleSlowFrames)
                .putLong("sample_wall_ms", System.currentTimeMillis())
                .apply();
            sampleStartNanos = SystemClock.elapsedRealtimeNanos();
            sampleFrames = 0;
            sampleSlowFrames = 0;
            sampleRenderNanos = 0L;
        }

        private void drawFrame() {
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) {
                    if (cachedW != c.getWidth() || cachedH != c.getHeight()) rebuildCaches(c.getWidth(), c.getHeight());
                    render(c);
                }
            } catch (RuntimeException ignored) {
                // The surface can disappear while Android changes wallpaper visibility.
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (RuntimeException ignored) {}
                }
            }
        }

        private void render(Canvas c) {
            int w = c.getWidth(), h = c.getHeight();
            float t = (SystemClock.elapsedRealtime() - start) / 1000f;
            SharedPreferences prefs = getSharedPreferences("living_world", MODE_PRIVATE);
            boolean max = prefs.getBoolean("max", false);
            c.drawColor(Color.rgb(5, 10, 25));
            paint.setShader(backgroundGradient);
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            int starCount = max ? starX.length : 100;
            for (int i = 0; i < starCount; i++) {
                float pulse = 1.0f + (float)Math.sin(t * 1.4f + starPhase[i]) * 0.35f;
                int alpha = 95 + (i % 145);
                paint.setColor(Color.argb(alpha, 170, 205, 255));
                c.drawCircle(starX[i], starY[i], (i % 4 == 0 ? 1.5f : 0.8f) * pulse, paint);
            }

            float cx = w * 0.5f + (float)Math.sin(t * 0.18f) * w * 0.06f;
            float cy = h * 0.48f + (float)Math.sin(t * 0.32f) * h * 0.025f;
            float r = orbRadius;
            // In MAX mode, strengthen the perceived depth/glow rather than trying to
            // exceed the physical refresh rate of the panel.
            paint.setColor(Color.argb(max ? 48 : 35, 55, 155, 255));
            c.drawCircle(cx, cy, r * (max ? 1.72f : 1.55f), paint);
            if (max) {
                paint.setColor(Color.argb(18, 75, 175, 255));
                c.drawCircle(cx, cy, r * 1.95f, paint);
            }
            if (orbGradient != null) {
                orbMatrix.setTranslate(cx, cy);
                orbGradient.setLocalMatrix(orbMatrix);
                paint.setShader(orbGradient);
                c.drawCircle(cx, cy, r, paint);
                paint.setShader(null);
            }

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1.5f, w * 0.002f));
            paint.setColor(Color.argb(100, 110, 205, 255));
            c.drawOval(cx-r*1.35f, cy-r*.32f, cx+r*1.35f, cy+r*.32f, paint);
            paint.setStyle(Paint.Style.FILL);

            int lights = max ? 28 : 12;
            for (int i = 0; i < lights; i++) {
                double a = t * (0.18 + i * 0.004) + i * Math.PI / (lights / 2.0);
                float x = cx + (float)Math.cos(a) * r * (1.15f + (i%3)*.12f);
                float y = cy + (float)Math.sin(a) * r * .48f;
                paint.setColor(Color.argb(220, 100 + (i%15)*10, 190, 255));
                c.drawCircle(x, y, 2.5f + (i%3), paint);
            }

            paint.setColor(Color.argb(170, 210, 232, 255));
            paint.setTextSize(Math.max(18, w * 0.035f));
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("LIVING WORLD", w * .5f, h * .82f, paint);
            paint.setTextSize(Math.max(10, w * .018f));
            paint.setColor(Color.argb(115, 150, 190, 230));
            c.drawText(max ? ("MAX DETAIL • DISPLAY TARGET " + Math.round(getMaximumRefreshRate()) + " HZ") : "A WORLD THAT NEVER STOPS CHANGING", w * .5f, h * .86f, paint);
        }
    }
}
