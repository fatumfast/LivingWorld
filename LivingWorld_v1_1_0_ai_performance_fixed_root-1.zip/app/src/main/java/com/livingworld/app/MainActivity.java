package com.livingworld.app;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Build;
import android.os.PowerManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.view.Display;
import android.view.WindowManager;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status;
    private TextView diagnostics;
    private String diagnosticReport = "";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("living_world", MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 40, 28, 28);
        root.setBackgroundColor(Color.rgb(8, 14, 28));
        root.setGravity(Gravity.TOP);
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("LIVING WORLD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Adaptive live wallpaper • AI Performance Diagnostics");
        subtitle.setTextColor(Color.rgb(155, 183, 220));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, 8, 0, 26);
        root.addView(subtitle);

        Switch max = new Switch(this);
        max.setText("MAX PERFORMANCE (WHEN VISIBLE)");
        max.setTextColor(Color.WHITE);
        max.setTextSize(19);
        max.setPadding(0, 12, 0, 20);
        max.setChecked(prefs.getBoolean("max", false));
        root.addView(max);
        max.setOnCheckedChangeListener((button, checked) -> {
            prefs.edit().putBoolean("max", checked).apply();
            status.setText(checked
                ? "MAX mode enabled: requests the highest supported display refresh rate (120/144 Hz when available) with enhanced visual detail. Only Android power-saver mode lowers this app's target; system thermal protection may still throttle performance."
                : "Balanced mode enabled: approximately 30 FPS target.");
        });

        status = new TextView(this);
        status.setTextColor(Color.rgb(195, 211, 235));
        status.setTextSize(15);
        status.setPadding(0, 14, 0, 24);
        status.setText(max.isChecked()
            ? "MAX mode enabled: requests the highest supported display refresh rate (120/144 Hz when available) with enhanced visual detail. Only Android power-saver mode lowers this app's target; system thermal protection may still throttle performance."
            : "Balanced mode enabled: approximately 30 FPS target.");
        root.addView(status);

        Button preview = new Button(this);
        preview.setText("OPEN LIVE WALLPAPER SETTINGS");
        root.addView(preview);
        preview.setOnClickListener(v -> {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, LivingWorldWallpaperService.class));
            try { startActivity(intent); }
            catch (Exception e) {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            }
        });

        Button inspect = new Button(this);
        inspect.setText("CHECK DEVICE / PERFORMANCE INFO");
        root.addView(inspect);
        diagnostics = new TextView(this);
        diagnostics.setTextColor(Color.rgb(195, 211, 235));
        diagnostics.setTextSize(13);
        diagnostics.setPadding(0, 12, 0, 8);
        diagnostics.setText("Device report not generated yet.");
        root.addView(diagnostics);
        inspect.setOnClickListener(v -> {
            diagnosticReport = createDeviceReport();
            diagnostics.setText(diagnosticReport);
        });

        Button copy = new Button(this);
        copy.setText("COPY DEVICE REPORT");
        root.addView(copy);
        copy.setOnClickListener(v -> {
            if (diagnosticReport.isEmpty()) diagnosticReport = createDeviceReport();
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("Living World device report", diagnosticReport));
            status.setText("Device report copied. You can paste it into ChatGPT.");
        });

        TextView note = new TextView(this);
        note.setText("\nMAX mode requests the highest refresh rate reported by the display for Living World's surface and synchronizes rendering to display VSync. The app does not voluntarily reduce its target for thermal status; only Android power-saver mode caps the target to 60 FPS. Android/device firmware can still throttle rendering or display refresh for thermal safety. This app cannot overclock CPU/GPU, exceed the panel refresh rate, change refresh behavior inside other apps, or force them to run at 120+ FPS.");
        note.setTextColor(Color.rgb(140, 155, 180));
        note.setTextSize(13);
        root.addView(note);
    }
    private String localRecommendation(SharedPreferences perf) {
        long age = System.currentTimeMillis() - perf.getLong("sample_wall_ms", 0L);
        if (age > 15000 || !perf.getBoolean("renderer_active", false)) {
            return "No fresh wallpaper sample. Set Living World as the home-screen wallpaper and leave it visible for 15 seconds, then check again.";
        }
        float fps = perf.getFloat("measured_fps", 0f);
        float renderMs = perf.getFloat("avg_render_ms", 0f);
        if (fps < 1f) return "No reliable FPS sample yet; keep the wallpaper visible and repeat diagnostics.";
        if (renderMs > 8f) return "Rendering cost is high for a 120 Hz target; next step is to profile drawing and reduce avoidable work.";
        if (fps < 55f) return "Measured cadence is below 60 FPS; check visibility, power saver, and system display mode before changing detail.";
        if (fps < 100f) return "Rendering is active but below a 120 Hz cadence; compare another sample and inspect frame pacing.";
        return "Recent rendering cadence is close to the display target; test for 10–20 minutes to check sustained stability.";
    }

    private String createDeviceReport() {
        StringBuilder out = new StringBuilder();
        out.append("Living World 1.1.0 — Performance report\n");
        out.append("Manufacturer: ").append(Build.MANUFACTURER).append("\n");
        out.append("Model: ").append(Build.MODEL).append("\n");
        out.append("Device: ").append(Build.DEVICE).append("\n");
        out.append("Android: ").append(Build.VERSION.RELEASE).append(" (API ").append(Build.VERSION.SDK_INT).append(")\n");
        out.append("Available CPU cores reported to app: ").append(Runtime.getRuntime().availableProcessors()).append("\n");
        Runtime rt = Runtime.getRuntime();
        out.append("App max heap: ").append(rt.maxMemory() / (1024 * 1024)).append(" MB\n");
        android.app.ActivityManager am = (android.app.ActivityManager) getSystemService(ACTIVITY_SERVICE);
        android.app.ActivityManager.MemoryInfo mi = new android.app.ActivityManager.MemoryInfo();
        am.getMemoryInfo(mi);
        out.append("Device RAM total: ").append(mi.totalMem / (1024 * 1024)).append(" MB\n");
        out.append("Device RAM available now: ").append(mi.availMem / (1024 * 1024)).append(" MB\n");
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();
        out.append("Current display refresh rate: ").append(display.getRefreshRate()).append(" Hz\n");
        float maxRefresh = display.getRefreshRate();
        if (Build.VERSION.SDK_INT >= 23) {
            for (Display.Mode mode : display.getSupportedModes()) maxRefresh = Math.max(maxRefresh, mode.getRefreshRate());
        }
        out.append("Maximum refresh rate reported by display: ").append(maxRefresh).append(" Hz\n");
        out.append("MAX mode target: highest reported display refresh rate while wallpaper is visible\n");
        SharedPreferences perf = getSharedPreferences("living_world_perf", MODE_PRIVATE);
        out.append("Wallpaper renderer status: ").append(perf.getBoolean("renderer_active", false) ? "recent frames recorded" : "no recent frames recorded").append("\n");
        out.append("Measured renderer FPS (recent sample): ").append(perf.getFloat("measured_fps", 0f)).append("\n");
        out.append("Average render time: ").append(perf.getFloat("avg_render_ms", 0f)).append(" ms\n");
        out.append("Slow-frame count in sample: ").append(perf.getInt("slow_frames", 0)).append("\n");
        out.append("Sample age: ").append(Math.max(0, (System.currentTimeMillis() - perf.getLong("sample_wall_ms", 0L)) / 1000)).append(" seconds\n");
        out.append("Local AI recommendation: ").append(localRecommendation(perf)).append("\n");
        out.append("Power saver: ");
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        out.append(pm.isPowerSaveMode() ? "ON" : "OFF").append("\n");
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                int thermal = pm.getCurrentThermalStatus();
                String[] names = {"NONE", "LIGHT", "MODERATE", "SEVERE", "CRITICAL", "EMERGENCY", "SHUTDOWN"};
                out.append("Thermal status: ").append(thermal >= 0 && thermal < names.length ? names[thermal] : thermal).append("\n");
            } catch (Exception e) { out.append("Thermal status: unavailable to app\n"); }
        } else out.append("Thermal status: API not available on this Android version\n");
        out.append("\nNote: these are diagnostic readings, not proof of maximum CPU/GPU clocks. Android may hide hardware details.");
        return out.toString();
    }

}
