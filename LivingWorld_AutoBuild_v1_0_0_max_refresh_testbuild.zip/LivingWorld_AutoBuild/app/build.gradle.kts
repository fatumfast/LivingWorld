plugins {
    id("com.android.application")
}

android {
    namespace = "com.livingworld.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.livingworld.app.v100"
        minSdk = 26
        targetSdk = 35
        versionCode = 10
        versionName = "1.0.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
