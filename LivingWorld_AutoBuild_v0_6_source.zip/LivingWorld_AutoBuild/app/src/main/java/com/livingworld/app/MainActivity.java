package com.livingworld.app;

import android.app.Activity;
import android.app.WallpaperManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences prefs;
    private TextView status;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("living_world", MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 40, 28, 28);
        root.setBackgroundColor(Color.rgb(8, 14, 28));
        root.setGravity(Gravity.TOP);
        setContentView(root);

        TextView title = new TextView(this);
        title.setText("LIVING WORLD");
        title.setTextColor(Color.WHITE);
        title.setTextSize(28);
        title.setGravity(Gravity.CENTER_VERTICAL);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Adaptive live wallpaper • Redmi Pad Pro");
        subtitle.setTextColor(Color.rgb(155, 183, 220));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, 8, 0, 26);
        root.addView(subtitle);

        Switch max = new Switch(this);
        max.setText("MAX PERFORMANCE");
        max.setTextColor(Color.WHITE);
        max.setTextSize(19);
        max.setPadding(0, 12, 0, 20);
        max.setChecked(prefs.getBoolean("max", false));
        root.addView(max);
        max.setOnCheckedChangeListener((button, checked) -> {
            prefs.edit().putBoolean("max", checked).apply();
            status.setText(checked
                ? "MAX mode enabled for Living World. The system still controls CPU/GPU clocks and temperature."
                : "Balanced mode enabled.");
        });

        status = new TextView(this);
        status.setTextColor(Color.rgb(195, 211, 235));
        status.setTextSize(15);
        status.setPadding(0, 14, 0, 24);
        status.setText(max.isChecked()
            ? "MAX mode enabled for Living World. The system still controls CPU/GPU clocks and temperature."
            : "Balanced mode enabled.");
        root.addView(status);

        Button preview = new Button(this);
        preview.setText("OPEN LIVE WALLPAPER SETTINGS");
        root.addView(preview);
        preview.setOnClickListener(v -> {
            Intent intent = new Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER);
            intent.putExtra(WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                new ComponentName(this, LivingWorldWallpaperService.class));
            try { startActivity(intent); }
            catch (Exception e) {
                startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER));
            }
        });

        TextView note = new TextView(this);
        note.setText("\nPerformance mode changes this wallpaper's rendering only. It cannot unlock disabled hardware, overclock system cores, or bypass thermal protection.");
        note.setTextColor(Color.rgb(140, 155, 180));
        note.setTextSize(13);
        root.addView(note);
    }
}
