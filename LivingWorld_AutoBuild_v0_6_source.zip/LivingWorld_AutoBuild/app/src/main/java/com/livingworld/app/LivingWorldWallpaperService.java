package com.livingworld.app;

import android.service.wallpaper.WallpaperService;
import android.view.SurfaceHolder;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Color;
import android.graphics.Rect;
import java.util.Random;

public class LivingWorldWallpaperService extends WallpaperService {
    @Override public Engine onCreateEngine() { return new WorldEngine(); }

    private final class WorldEngine extends Engine {
        private final Handler handler = new Handler(Looper.getMainLooper());
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Random random = new Random(71);
        private boolean visible;
        private long start = SystemClock.elapsedRealtime();
        private final Runnable drawTask = new Runnable() {
            @Override public void run() {
                drawFrame();
            }
        };

        @Override public void onVisibilityChanged(boolean isVisible) {
            visible = isVisible;
            if (visible) drawFrame(); else handler.removeCallbacks(drawTask);
        }

        @Override public void onSurfaceChanged(SurfaceHolder holder, int format, int width, int height) {
            super.onSurfaceChanged(holder, format, width, height);
            if (visible) drawFrame();
        }

        @Override public void onSurfaceDestroyed(SurfaceHolder holder) {
            visible = false;
            handler.removeCallbacks(drawTask);
            super.onSurfaceDestroyed(holder);
        }

        private void drawFrame() {
            handler.removeCallbacks(drawTask);
            if (!visible) return;
            SurfaceHolder holder = getSurfaceHolder();
            Canvas c = null;
            try {
                c = holder.lockCanvas();
                if (c != null) render(c);
            } catch (Exception ignored) {
            } finally {
                if (c != null) {
                    try { holder.unlockCanvasAndPost(c); } catch (Exception ignored) {}
                }
            }
            SharedPreferences p = getSharedPreferences("living_world", MODE_PRIVATE);
            boolean max = p.getBoolean("max", false);
            handler.postDelayed(drawTask, max ? 16L : 33L);
        }

        private void render(Canvas c) {
            int w = c.getWidth(), h = c.getHeight();
            float t = (SystemClock.elapsedRealtime() - start) / 1000f;
            c.drawColor(Color.rgb(5, 10, 25));
            paint.setShader(new android.graphics.LinearGradient(0, 0, 0, h,
                Color.rgb(8, 20, 50), Color.rgb(2, 4, 12),
                android.graphics.Shader.TileMode.CLAMP));
            c.drawRect(0, 0, w, h, paint);
            paint.setShader(null);

            // Stars: deterministic, low-cost pseudo-random field.
            for (int i = 0; i < 100; i++) {
                float x = ((i * 137.5f) % Math.max(1, w));
                float y = ((i * 83.7f) % Math.max(1, h));
                float pulse = 1.0f + (float)Math.sin(t * 1.4 + i) * 0.45f;
                paint.setColor(Color.argb(100 + (i % 150), 170, 205, 255));
                c.drawCircle(x, y, (i % 3 == 0 ? 1.5f : 0.8f) * pulse, paint);
            }

            // Animated horizon and a glowing world orb.
            float cx = w * 0.5f + (float)Math.sin(t * 0.18) * w * 0.06f;
            float cy = h * 0.48f + (float)Math.sin(t * 0.32) * h * 0.025f;
            float r = Math.min(w, h) * 0.22f;
            paint.setColor(Color.argb(35, 55, 155, 255));
            c.drawCircle(cx, cy, r * 1.55f, paint);
            paint.setShader(new android.graphics.RadialGradient(cx-r*.25f, cy-r*.3f, r*1.5f,
                new int[]{Color.rgb(95, 205, 255), Color.rgb(27, 75, 155), Color.rgb(4, 13, 43)},
                null, android.graphics.Shader.TileMode.CLAMP));
            c.drawCircle(cx, cy, r, paint);
            paint.setShader(null);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(Math.max(1.5f, w * 0.002f));
            paint.setColor(Color.argb(100, 110, 205, 255));
            c.drawOval(cx-r*1.35f, cy-r*.32f, cx+r*1.35f, cy+r*.32f, paint);
            paint.setStyle(Paint.Style.FILL);

            // Floating lights orbit around the globe.
            for (int i = 0; i < 12; i++) {
                double a = t * (0.18 + i * 0.006) + i * Math.PI / 6;
                float x = cx + (float)Math.cos(a) * r * (1.15f + (i%3)*.12f);
                float y = cy + (float)Math.sin(a) * r * .48f;
                paint.setColor(Color.argb(220, 100 + i*10, 190, 255));
                c.drawCircle(x, y, 2.5f + (i%3), paint);
            }

            paint.setColor(Color.argb(170, 210, 232, 255));
            paint.setTextSize(Math.max(18, w * 0.035f));
            paint.setTextAlign(Paint.Align.CENTER);
            c.drawText("LIVING WORLD", w * .5f, h * .82f, paint);
            paint.setTextSize(Math.max(10, w * .018f));
            paint.setColor(Color.argb(115, 150, 190, 230));
            c.drawText("A WORLD THAT NEVER STOPS CHANGING", w * .5f, h * .86f, paint);
        }
    }
}
