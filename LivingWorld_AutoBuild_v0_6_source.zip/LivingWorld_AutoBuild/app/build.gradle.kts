plugins {
    id("com.android.application")
}

android {
    namespace = "com.livingworld.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.livingworld.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "0.6.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
